#ifndef SCOREBOARD_H
#define SCOREBOARD_H
#include <string>

using namespace std;

class Scoreboard{ 
    public:
    //Default Constructor
        Scoreboard();

    //Setters
        void setPlayerName(string inputPlayer);
        void setMoneyGain(int inputMoney);
        void setMoneyLoss(int inputMoney);
        void setMoney(int inputMoney);

    //Getters
        int getMoney();
        string getPlayerName();
        
    //Data Members
    private:
        string playerName;
        int money;       
};
#endif