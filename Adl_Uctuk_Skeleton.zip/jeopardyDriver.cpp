#include "Questions.h"
#include "Category.h"
#include "Scoreboard.h"
#include "Leaderboard.h"
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

/*Function split as an integer
Parameters are text as string, seperator as character, the array as string, and the size of the array as integer*/
int split(string text, char seperator, string arr[], int size){

    //If the length of the text, or the size is equal to 0, return 0
    if (text.length() == 0 || size == 0){
        return 0;
    }

    //Initalize number as integer equal to 0
    //Initalize len as integer equal to the length of the text
    //Initalize the word as a string variable, this will hold each word in the string
    int num = 0;
    int len = text.length();
    string word = "";

    //For loop with i set to 0, terminate when i reaches the length
    for (int i = 0; i < len; i++){

        /*If the text with position i does not equal the seperator, 
        input each character of the word until the seperator*/
        if (text[i] != seperator){
            word = word + text[i];
        }

        /*Else the array with index number is equal to the word
        Increase number by 1
        Reset word to an empty string*/
        else{
            arr[num] = word;
            num++;
            word = "";
        }
    }
    //Put the last word into the array and increase number by 1
    if (num < size){
        arr[num] = word;
        num++;
    }

    //If the number is bigger than the size of the array, return -1
    if (num > size){
        return -1;
    }

    //Return number
    return num;
}

int main(){

    //Test Questions class and Scoreboard Class
    string line = "";
    Questions question;
    Scoreboard scoreboard;
    string answer;
    int numOfLines = 0;
    int money = 0;
    int num = 0;

    //Set player name
    scoreboard.setPlayerName("Jake");

    //File name for questions
    string fileName = "memeQuestions.txt";
    ifstream inFile(fileName);
    string arr[50];

    //Random number between 1 and 23
    srand(time(0));
    int random = rand() % 23 + 1;

    //Terminate at end of file
    while(getline(inFile, line)){

        //Calculate number of lines in file
        numOfLines++;

        //If the line number and the random number are equal
        if(numOfLines == random){

            //Call split function
            num = split(line, ',', arr, 50);

            //For multiple choice questions, number of splits are greater than 2
            if(num > 2){

                //arr of 0 is the question, call member function
                question.setQuestion(arr[0]);
                cout << question.getQuestion() << endl;

                //4 multiple choice answers
                for(int i = 1; i < 5; i++){

                    //arr of 1 to 4 are the multiple choice questions, call member function 
                    question.setChoices(arr[i]);
                    cout << question.getChoices() << endl;
                }
                cout << endl;

                //arr of 5 is the actual answer, call member function to set answer
                question.setAnswer(arr[5]);
            }

            //For free response questions, number of splits is equal to 2
            else{

                //array of 0 is the question and array of 1 is the answer
                question.setQuestion(arr[0]);
                question.setAnswer(arr[1]);
                cout << question.getQuestion() << endl;
            }

            //Input answer
            cout << "Your answer:" << endl;
            getline(cin, answer);

            /*Check the answer using member function from questions class, 
            if it is correct, add the point value they entered (100) to the total money using scoreboard class
            if it is incorrect, subtract that money from their total*/
            if(question.checkAnswer(answer) == true){
                scoreboard.setMoneyGain(200);
                cout << "Correct, " << scoreboard.getPlayerName() << "'s total amount is now $" << scoreboard.getMoney() << endl;
            }
            else{
                scoreboard.setMoneyLoss(200);
                cout << "Incorrect, the correct answer is " << question.getAnswer() << ", " << scoreboard.getPlayerName() << "'s total amount is now $" << scoreboard.getMoney() << endl;
            }
        }
    }

    //Test Category class
    string line1 = "";
    Category category[50];
    int i = 0;

    //File name for categories
    string fileName1 = "Category.txt";
    ifstream inFile1(fileName1);

    //Terminate at end of file, put category into array
    while(getline(inFile1, line)){
        category[i].setCategory(line);
        i++;
    }

    //Ouput category at index 0
    cout << category[0].getCategory() << endl;
    cout << category[5].getCategory() << endl;



    //Test Leaderboard Class
    int numOfPlayers = 0;
    Leaderboard leaderboard[50];
    string arr2[50];

    //File name for players
    string fileName2 = "players.txt";
    ifstream inFile2(fileName2);
    string line2 = "";
    
    //Vector pair with integer for their score and string for name of player
    vector<pair<int, string>> leader;

    //Terminate at end of file
    while(getline(inFile2, line2)){

        //Call split function
        split(line2, ',', arr, 50);

        /*Fill leaderboard array with leaderboard object, array of 0 is player name, array of 1 is score,
        increment numOfPlayers by 1*/
        leaderboard[numOfPlayers] = Leaderboard(arr[0], stoi(arr[1]));
        numOfPlayers++;
    }

    //Put the money corresponding with the name into the vector
    for(int i = 0; i < numOfPlayers; i++){
        leader.push_back(make_pair(leaderboard[i].getMoney(), leaderboard[i].getName()));
    }

    //Sort vector in descending order
    sort(leader.rbegin(), leader.rend());

    //Output leaderboard, name then score
    cout << "===========Leader Board===========" << endl;
    for (int i = 0; i < numOfPlayers; i++){
        cout << i + 1 << ". " << leader[i].second << " " << leader[i].first << endl;
    }
}